from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder= 'templates')

#funzione per creare database e tabelle se non esistono

def create_database():
    try:
        #connessione al server Mysql per eseguire le query
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        #creo il cursore per eseguire le query
        cursor = connection.cursor()

        # query per creare database se non esiste
        cursor.execute("DROP DATABASE IF EXISTS GestioneLibreria")
        cursor.execute("CREATE DATABASE GestioneLibreria")
        cursor.execute("USE GestioneLibreria")

        # query per creare tabella CONTATTI (Clienti e Dipendenti)
        cursor.execute("CREATE TABLE IF NOT EXISTS contatti (id INT PRIMARY KEY AUTO_INCREMENT, nome VARCHAR(255),cognome VARCHAR(255), codice_fiscale VARCHAR(16) UNIQUE,data_nascita DATE,categoria ENUM('cliente','dipendente') NOT NULL)")

        # query per creare tabella RECAPITI (email, telefono)
        cursor.execute("CREATE TABLE IF NOT EXISTS recapiti ( id INT PRIMARY KEY AUTO_INCREMENT, contatto_id INT,tipo ENUM('email','telefono'),valore VARCHAR(255),FOREIGN KEY (contatto_id) REFERENCES contatti(id) ON DELETE CASCADE)")

        # query per creare tabella INDIRIZZI
        cursor.execute("CREATE TABLE IF NOT EXISTS indirizzi (id INT PRIMARY KEY AUTO_INCREMENT,contatto_id INT,via VARCHAR(255),citta VARCHAR(255),cap VARCHAR(10),provincia VARCHAR(50), nazione VARCHAR(50),FOREIGN KEY (contatto_id) REFERENCES contatti(id) ON DELETE CASCADE)")

        # query per creare tabella UTENTI (login)
        cursor.execute("CREATE TABLE IF NOT EXISTS utenti (id INT PRIMARY KEY AUTO_INCREMENT,contatto_id INT UNIQUE,username VARCHAR(50) UNIQUE,password VARCHAR(255) NOT NULL,FOREIGN KEY (contatto_id) REFERENCES contatti(id) ON DELETE CASCADE)")

        #query per creare tabella LIBRI
        cursor.execute("CREATE TABLE IF NOT EXISTS libri (id INT PRIMARY KEY AUTO_INCREMENT,titolo VARCHAR(255),autore VARCHAR(255),descrizione TEXT,prezzo DECIMAL(6,2))")

        #query per creare tabella GENERI
        cursor.execute("CREATE TABLE IF NOT EXISTS generi (id INT PRIMARY KEY AUTO_INCREMENT,nome VARCHAR(50) UNIQUE)")

        #query per creare tabella LIBRI_GENERI per metterli in relazione
        cursor.execute("CREATE TABLE IF NOT EXISTS libri_generi (libro_id INT,genere_id INT,PRIMARY KEY (libro_id, genere_id),FOREIGN KEY (libro_id) REFERENCES libri(id) ON DELETE CASCADE,FOREIGN KEY (genere_id) REFERENCES generi(id) ON DELETE CASCADE)")

        #query per creare tabella STOCK (magazzino)
        cursor.execute("CREATE TABLE IF NOT EXISTS stock (id INT PRIMARY KEY AUTO_INCREMENT,libro_id INT UNIQUE,copie_disponibili INT,FOREIGN KEY (libro_id) REFERENCES libri(id) ON DELETE CASCADE)")

        #query per creare tabella VENDITE (sales)
        cursor.execute("CREATE TABLE IF NOT EXISTS sales (id INT PRIMARY KEY AUTO_INCREMENT,contatto_id INT,libro_id INT,quantita INT,data_vendita DATETIME DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY (contatto_id) REFERENCES contatti(id) ON DELETE CASCADE,FOREIGN KEY (libro_id) REFERENCES libri(id) ON DELETE CASCADE)")

        # Inserisco dati iniziali di test

        #Controllo se esiste già l'utente admin
        cursor.execute("SELECT COUNT(*) FROM utenti WHERE username='admin'")
        if cursor.fetchone()[0] == 0:
            #Creo il contatto (dipendente)
            cursor.execute("INSERT INTO contatti (nome, cognome, codice_fiscale, data_nascita, categoria) VALUES ('Admin','Sistema','RSSMRA80A01H501Z','1980-01-01','dipendente')")

            contatto_id = cursor.lastrowid

            #Creo utente collegato con password hashata
            password_hash = generate_password_hash('0000')

            cursor.execute("INSERT INTO utenti (contatto_id, username, password) VALUES (%s, %s, %s)", (contatto_id, 'admin', password_hash))

        # Generi
        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Fantasy'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Fantasy')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Avventura'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Avventura')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Storia'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Storia')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Romantico'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Romantico')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Giallo'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Giallo')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Classici'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Classici')")

        cursor.execute("SELECT COUNT(*) FROM generi WHERE nome='Horror'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO generi (nome) VALUES ('Horror')")


        # Libro
        cursor.execute("SELECT COUNT(*) FROM libri WHERE titolo='Harry Potter e la Pietra Filosofale'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO libri (titolo, autore, descrizione, prezzo)
                VALUES ('Harry Potter e la Pietra Filosofale',
                        'J.K. Rowling',
                        'Primo capitolo della saga del maghetto più famoso del mondo',
                        19.90)
            """)

            libro_id = cursor.lastrowid

            # Recupero id generi
            cursor.execute("SELECT id FROM generi WHERE nome='Fantasy'")
            genere_fantasy_id = cursor.fetchone()[0]

            cursor.execute("SELECT id FROM generi WHERE nome='Avventura'")
            genere_avventura_id = cursor.fetchone()[0]

            # Relazione N:M
            cursor.execute("""
                INSERT INTO libri_generi (libro_id, genere_id)
                VALUES (%s, %s)
            """, (libro_id, genere_fantasy_id))

            cursor.execute("""
                INSERT INTO libri_generi (libro_id, genere_id)
                VALUES (%s, %s)
            """, (libro_id, genere_avventura_id))

            # Stock
            cursor.execute("""
                INSERT INTO stock (libro_id, copie_disponibili)
                VALUES (%s, %s)
            """, (libro_id, 5))

        # =========================
        # CLIENTE MARIO ROSSI
        # =========================

        cursor.execute("SELECT COUNT(*) FROM contatti WHERE codice_fiscale='RSSMRA90A01H501X'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO contatti (nome, cognome, codice_fiscale, data_nascita, categoria)
                VALUES ('Mario','Rossi','RSSMRA90A01H501X','1990-01-01','cliente')
            """)

            contatto_id = cursor.lastrowid

            # Email
            cursor.execute("""
                INSERT INTO recapiti (contatto_id, tipo, valore)
                VALUES (%s, %s, %s)
            """, (contatto_id, 'email', 'mariorossi@email.com'))

            # Telefono
            cursor.execute("""
                INSERT INTO recapiti (contatto_id, tipo, valore)
                VALUES (%s, %s, %s)
            """, (contatto_id, 'telefono', '333456789'))

            # Indirizzo
            cursor.execute("""
                INSERT INTO indirizzi (contatto_id, via, citta, cap, provincia, nazione)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (contatto_id, 'Via Roma 12', 'Roma', '00100', 'RM', 'Italia'))
        connection.commit()
        cursor.close()
        connection.close()
        print("Database, tabelle e dati creati con successo!!")

    except Exception as e:
        print("Errore durante la creazione del database:", e)

#eseguo creazione del database
create_database()

# configurazione della connessione al database

db = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = "",
    database = "GestioneLibreria"
)

#creo cursore per eseguire le query sull'oggetto db
cursor = db.cursor()

#Creo route pubblica principale
@app.route('/')
def index():
    return render_template("index.html")
#-------------------------------------------------------------------------------------------------------------------------------------
#Creo route per la visualizzazione pubblica dei libri
@app.route('/catalogo')
def catalogo_pubblico():
    cursor.execute("SELECT l.titolo, l.autore, l.descrizione, l.prezzo, GROUP_CONCAT(g.nome SEPARATOR ', ') AS generi, s.copie_disponibili FROM libri l JOIN stock s ON l.id = s.libro_id LEFT JOIN libri_generi lg ON l.id=lg.libro_id LEFT JOIN generi g ON lg.genere_id=g.id GROUP BY l.id")

    libri = cursor.fetchall()

    return render_template("catalogo.html", libri=libri)
#-------------------------------------------------------------------------------------------------------------------------------------
#Creo route per il login
@app.route('/login', methods=['GET', 'POST'])
def login():
    errore = None

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Prendo l'utente dal database
        cursor.execute("SELECT id, password FROM utenti WHERE username=%s", (username,))
        utente = cursor.fetchone()

        if utente:
            # utente trovato, controllo password
            password_hash = utente[1]
            if check_password_hash(password_hash, password):
                # login corretto: reindirizzo al menù principale
                return redirect(url_for('menu_principale'))
            else:
                errore = "Password errata!"
        else:
            errore = "Username non trovato!"

    return render_template('login.html', errore=errore)

#--------------------------------------------------------------------------------------------------------------------------

#creo route per la pagina index.html che conterrà il menù principale di navigazione
@app.route('/menu_principale')
def menu_principale():
    return render_template('menu_principale.html')

#-----------------------------------------------------------------------------------------------------------------------------

#Creo route per il logout
@app.route('/logout')
def logout():
    return redirect(url_for('login'))

#-----------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------
# Route per visualizzare lista libri
@app.route('/libri')
def lista_libri():
    try:
        ricerca = request.args.get('ricerca')

        if ricerca:
            valore = "%" + ricerca + "%"
            cursor.execute("""
                SELECT l.id, l.titolo, l.autore, l.descrizione, s.copie_disponibili,
                       GROUP_CONCAT(g.nome SEPARATOR ', ') AS generi
                FROM libri l
                LEFT JOIN stock s ON l.id = s.libro_id
                LEFT JOIN libri_generi lg ON l.id = lg.libro_id
                LEFT JOIN generi g ON lg.genere_id = g.id
                WHERE l.titolo LIKE %s OR l.autore LIKE %s
                GROUP BY l.id
            """, (valore, valore))
        else:
            cursor.execute("""
                SELECT l.id, l.titolo, l.autore, l.descrizione, s.copie_disponibili,
                       GROUP_CONCAT(g.nome SEPARATOR ', ') AS generi
                FROM libri l
                LEFT JOIN stock s ON l.id = s.libro_id
                LEFT JOIN libri_generi lg ON l.id = lg.libro_id
                LEFT JOIN generi g ON lg.genere_id = g.id
                GROUP BY l.id
            """)
        libri = cursor.fetchall()
        return render_template('libri.html', libri=libri, ricerca=ricerca)
    except Exception as e:
        return f"Errore durante visualizzazione libri: {e}"

#-----------------------------------------------
# Route per aggiungere un libro
@app.route('/libri/aggiungi', methods=['GET','POST'])
def aggiungi_libro():
    if request.method == 'POST':
        titolo = request.form['titolo'].strip()
        autore = request.form['autore'].strip()
        descrizione = request.form['descrizione'].strip()
        prezzo = request.form['prezzo']
        copie = int(request.form['copie'])
        generi_selezionati = request.form.getlist('generi')  # lista di id generi dal form

        try:
            # Inserisco libro
            cursor.execute("INSERT INTO libri (titolo, autore, descrizione, prezzo) VALUES (%s, %s, %s, %s)",
                           (titolo, autore, descrizione, prezzo))
            libro_id = cursor.lastrowid

            # Inserisco stock
            cursor.execute("INSERT INTO stock (libro_id, copie_disponibili) VALUES (%s, %s)", (libro_id, copie))

            # Inserisco generi (relazione N:M)
            for genere_id in generi_selezionati:
                cursor.execute("INSERT INTO libri_generi (libro_id, genere_id) VALUES (%s, %s)", (libro_id, genere_id))

            db.commit()
            return redirect(url_for('lista_libri'))

        except Exception as e:
            db.rollback()
            return f"Errore durante inserimento libro: {e}"

    # Recupero lista generi per il form
    cursor.execute("SELECT id, nome FROM generi")
    generi = cursor.fetchall()
    return render_template('aggiungi_libro.html', generi=generi)

#-------------------------------------------------------------------------------------------------------------------------

@app.route('/libri/elimina/<int:id>')
def elimina_libro(id):
    try:

        cursor.execute("DELETE FROM libri_generi WHERE libro_id=%s", (id,))
        cursor.execute("DELETE FROM stock WHERE libro_id=%s", (id,))
        cursor.execute("DELETE FROM libri WHERE id=%s", (id,))

        db.commit()

        return redirect(url_for('lista_libri'))

    except Exception as e:
        db.rollback()
        return f"Errore eliminazione libro: {e}"
#-------------------------------------------------------------------------------------------------------------------------

@app.route('/libri/modifica/<int:id>', methods=['GET','POST'])
def modifica_libro(id):

    if request.method == 'POST':

        titolo = request.form['titolo']
        autore = request.form['autore']
        descrizione = request.form['descrizione']
        prezzo = request.form['prezzo']
        copie = request.form['copie']
        generi = request.form.getlist('generi')

        try:

            cursor.execute("""
                UPDATE libri
                SET titolo=%s, autore=%s, descrizione=%s, prezzo=%s
                WHERE id=%s
            """, (titolo, autore, descrizione, prezzo, id))

            cursor.execute("""
                UPDATE stock
                SET copie_disponibili=%s
                WHERE libro_id=%s
            """, (copie, id))

            # reset generi
            cursor.execute("DELETE FROM libri_generi WHERE libro_id=%s", (id,))

            for genere in generi:
                cursor.execute("""
                    INSERT INTO libri_generi (libro_id, genere_id)
                    VALUES (%s,%s)
                """, (id, genere))

            db.commit()

            return redirect(url_for('lista_libri'))

        except Exception as e:
            db.rollback()
            return f"Errore modifica libro: {e}"

    cursor.execute("""
        SELECT l.id, l.titolo, l.autore, l.descrizione, l.prezzo,
               s.copie_disponibili
        FROM libri l
        LEFT JOIN stock s ON l.id=s.libro_id
        WHERE l.id=%s
    """, (id,))

    libro = cursor.fetchone()

    cursor.execute("SELECT id, nome FROM generi")
    generi = cursor.fetchall()

    cursor.execute("SELECT genere_id FROM libri_generi WHERE libro_id=%s", (id,))
    generi_libro = [g[0] for g in cursor.fetchall()]

    return render_template(
        'modifica_libro.html',
        libro=libro,
        generi=generi,
        generi_libro=generi_libro
    )

#---------------------------------------------------------------------------------------------------------------------------------

@app.route('/contatti')
def lista_contatti():

    try:

        cursor.execute("""
            SELECT 
                c.id,
                c.nome,
                c.cognome,
                c.codice_fiscale,
                c.data_nascita,
                c.categoria,

                e.valore AS email,
                t.valore AS telefono,

                i.via,
                i.citta,
                i.cap,
                i.provincia,
                i.nazione

            FROM contatti c

            LEFT JOIN recapiti e 
                ON c.id = e.contatto_id AND e.tipo = 'email'

            LEFT JOIN recapiti t 
                ON c.id = t.contatto_id AND t.tipo = 'telefono'

            LEFT JOIN indirizzi i 
                ON c.id = i.contatto_id

            ORDER BY c.cognome, c.nome
        """)

        contatti = cursor.fetchall()

        return render_template("lista_contatti.html", contatti=contatti)

    except Exception as e:
        return f"Errore caricamento contatti: {e}"

#----------------------------------------------------------------------------------------------------------------------------

@app.route('/contatti/aggiungi', methods=['GET','POST'])
def aggiungi_contatto():

    if request.method == 'POST':

        nome = request.form['nome']
        cognome = request.form['cognome']
        codice_fiscale = request.form['codice_fiscale']
        data_nascita = request.form['data_nascita']
        categoria = request.form['categoria']

        email = request.form['email']
        telefono = request.form['telefono']

        via = request.form['via']
        citta = request.form['citta']
        cap = request.form['cap']
        provincia = request.form['provincia']
        nazione = request.form['nazione']

        try:

            # CONTATTO
            cursor.execute("""
                INSERT INTO contatti
                (nome,cognome,codice_fiscale,data_nascita,categoria)
                VALUES (%s,%s,%s,%s,%s)
            """,(nome,cognome,codice_fiscale,data_nascita,categoria))

            contatto_id = cursor.lastrowid

            # EMAIL
            cursor.execute("""
                INSERT INTO recapiti (contatto_id,tipo,valore)
                VALUES (%s,'email',%s)
            """,(contatto_id,email))

            # TELEFONO
            cursor.execute("""
                INSERT INTO recapiti (contatto_id,tipo,valore)
                VALUES (%s,'telefono',%s)
            """,(contatto_id,telefono))

            # INDIRIZZO
            cursor.execute("""
                INSERT INTO indirizzi
                (contatto_id,via,citta,cap,provincia,nazione)
                VALUES (%s,%s,%s,%s,%s,%s)
            """,(contatto_id,via,citta,cap,provincia,nazione))

            db.commit()

            return redirect(url_for('lista_contatti'))

        except Exception as e:
            db.rollback()
            return f"Errore inserimento contatto: {e}"

    return render_template("aggiungi_contatto.html")

#-----------------------------------------------------------------------------------------------------------------------------

@app.route('/contatti/modifica/<int:id>', methods=['GET','POST'])
def modifica_contatto(id):

    try:

        if request.method == 'POST':

            nome = request.form['nome']
            cognome = request.form['cognome']
            codice_fiscale = request.form['codice_fiscale']
            data_nascita = request.form['data_nascita']
            categoria = request.form['categoria']

            email = request.form['email']
            telefono = request.form['telefono']

            via = request.form['via']
            citta = request.form['citta']
            cap = request.form['cap']
            provincia = request.form['provincia']
            nazione = request.form['nazione']

            # contatti
            cursor.execute("""
                UPDATE contatti
                SET nome=%s,cognome=%s,codice_fiscale=%s,data_nascita=%s,categoria=%s
                WHERE id=%s
            """,(nome,cognome,codice_fiscale,data_nascita,categoria,id))

            # EMAIL
            cursor.execute("""
            SELECT id FROM recapiti 
            WHERE contatto_id=%s AND tipo='email'
            """, (id,))
            email_esiste = cursor.fetchone()

            if email_esiste:
                cursor.execute("""
                UPDATE recapiti
                SET valore=%s
                WHERE contatto_id=%s AND tipo='email'
                """, (email, id))
            else:
                cursor.execute("""
                INSERT INTO recapiti (contatto_id,tipo,valore)
                VALUES (%s,'email',%s)
                """, (id, email))

            # TELEFONO
            cursor.execute("""
            SELECT id FROM recapiti 
            WHERE contatto_id=%s AND tipo='telefono'
            """, (id,))
            tel_esiste = cursor.fetchone()

            if tel_esiste:
                cursor.execute("""
                UPDATE recapiti
                SET valore=%s
                WHERE contatto_id=%s AND tipo='telefono'
                """, (telefono, id))
            else:
                cursor.execute("""
                INSERT INTO recapiti (contatto_id,tipo,valore)
                VALUES (%s,'telefono',%s)
                """, (id, telefono))

            # indirizzo
            cursor.execute("""
                UPDATE indirizzi
                SET via=%s,citta=%s,cap=%s,provincia=%s,nazione=%s
                WHERE contatto_id=%s
            """,(via,citta,cap,provincia,nazione,id))

            db.commit()

            return redirect(url_for('lista_contatti'))

        # GET

        cursor.execute("""
            SELECT 
                c.id,
                c.nome,
                c.cognome,
                c.codice_fiscale,
                c.data_nascita,
                c.categoria,
                e.valore AS email,
                t.valore AS telefono,
                i.via,
                i.citta,
                i.cap,
                i.provincia,
                i.nazione
            FROM contatti c

            LEFT JOIN recapiti e 
                ON c.id = e.contatto_id AND e.tipo = 'email'

            LEFT JOIN recapiti t 
                ON c.id = t.contatto_id AND t.tipo = 'telefono'

            LEFT JOIN indirizzi i 
                ON c.id = i.contatto_id

            WHERE c.id = %s
        """, (id,))

        contatto = cursor.fetchone()

        return render_template("modifica_contatto.html",contatto=contatto)

    except Exception as e:
        db.rollback()
        return f"Errore modifica contatto: {e}"

#------------------------------------------------------------------------------------------------------------------------------

@app.route('/contatti/elimina/<int:id>')
def elimina_contatto(id):

    try:

        cursor.execute("DELETE FROM contatti WHERE id=%s",(id,))
        db.commit()

        return redirect(url_for('lista_contatti'))

    except Exception as e:
        db.rollback()
        return f"Errore eliminazione contatto: {e}"

#-----------------------------------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------
# Route per acquisto libri da clienti esistenti
@app.route('/acquista', methods=['GET', 'POST'])
def acquista():
    messaggio = request.args.get('messaggio')
    errore = request.args.get('errore')

    # Prendo la lista dei clienti
    cursor.execute("SELECT id, nome, cognome FROM contatti")
    clienti = cursor.fetchall()

    # Prendo la lista dei libri con copie disponibili
    cursor.execute("SELECT l.id, l.titolo, s.copie_disponibili FROM libri l JOIN stock s ON l.id = s.libro_id")
    libri = cursor.fetchall()

    if request.method == 'POST':
        contatto_id = request.form['contatto_id']
        libro_id = request.form['libro_id']
        quantita = int(request.form['quantita'])

        try:
            # Controllo disponibilità
            cursor.execute("SELECT copie_disponibili FROM stock WHERE libro_id = %s", (libro_id,))
            risultato = cursor.fetchone()

            if not risultato:
                return render_template("acquista.html", clienti=clienti, libri=libri, errore="Libro non presente in magazzino!")

            copie_disponibili = risultato[0]
            if copie_disponibili < quantita:
                return render_template("acquista.html", clienti=clienti, libri=libri, errore="Copie insufficienti in magazzino!")

            # Inserisco la vendita
            cursor.execute("INSERT INTO sales (contatto_id, libro_id, quantita) VALUES (%s, %s, %s)",
                           (contatto_id, libro_id, quantita))

            # Aggiorno il magazzino
            cursor.execute("UPDATE stock SET copie_disponibili = copie_disponibili - %s WHERE libro_id = %s",
                           (quantita, libro_id))

            db.commit()
            return redirect(url_for('acquista', messaggio="Vendita completata con successo!"))

        except Exception as e:
            db.rollback()
            return render_template("acquista.html", clienti=clienti, libri=libri,
                                   errore=f"Errore durante il processo di acquisto: {e}")

    return render_template("acquista.html", clienti=clienti, libri=libri, messaggio=messaggio)


#----------------------------------------------------------------------------------------------------
# Route per acquisto da nuovo cliente
@app.route('/acquista_nuovo', methods=['GET', 'POST'])
def acquista_nuovo():

    messaggio2 = request.args.get('messaggio2')
    errore2 = request.args.get('errore2')

    # prendo i libri
    cursor.execute("""
           SELECT l.id, l.titolo, s.copie_disponibili
           FROM libri l
           JOIN stock s ON l.id = s.libro_id
       """)
    libri = cursor.fetchall()

    if request.method == 'POST':

        # Dati dal form
        nome = request.form['nome']
        cognome = request.form['cognome']
        email = request.form['email']
        telefono = request.form['telefono']
        indirizzo = request.form['indirizzo']

        libro_id = request.form['libro_id']
        quantita = int(request.form['quantita'])

        try:

            #Controllo lo stock
            cursor.execute(
                "SELECT copie_disponibili FROM stock WHERE libro_id = %s",
                (libro_id,)
            )
            risultato = cursor.fetchone()

            if risultato is None:
                return redirect(url_for('acquista_nuovo', errore2="Libro non trovato."))

            copie = risultato[0]

            if copie < quantita:
                return redirect(url_for('acquista_nuovo',errore2="Copie non sufficienti in magazzino!"))

            #Creo il cliente
            cursor.execute("""
            INSERT INTO contatti (nome, cognome,categoria)
            VALUES (%s, %s, 'cliente')
            """, (nome, cognome))

            contatto_id = cursor.lastrowid

            #Inserisco email
            cursor.execute("""
            INSERT INTO recapiti (contatto_id, tipo, valore)
            VALUES (%s, 'email', %s)
            """, (contatto_id, email))

            #Inserisco telefono
            cursor.execute("""
            INSERT INTO recapiti (contatto_id, tipo, valore)
            VALUES (%s, 'telefono', %s)
            """, (contatto_id, telefono))

            #Inserisco indirizzo
            cursor.execute("""
            INSERT INTO indirizzi (contatto_id, via)
            VALUES (%s, %s)
            """, (contatto_id, indirizzo))

            #Registro la vendita
            cursor.execute("""
            INSERT INTO sales (contatto_id, libro_id, quantita)
            VALUES (%s, %s, %s)
            """, (contatto_id, libro_id, quantita))

            #Aggiorno lo stock
            cursor.execute("""
            UPDATE stock
            SET copie_disponibili = copie_disponibili - %s
            WHERE libro_id = %s
            """, (quantita, libro_id))

            db.commit()

            return redirect(url_for(
                'acquista_nuovo',
                messaggio2="Vendita completata con successo!"
            ))

        except Exception as e:
            db.rollback()

            return redirect(url_for(
                'acquista_nuovo',
                errore2=f"Errore durante il processo: {e}"
            ))
    return render_template("acquista_nuovo.html",libri=libri,messaggio2=messaggio2,errore2=errore2)
#------------------------------------------------------------------------------------------------------------------------

@app.route('/storico_vendite')
def storico_vendite():

    try:

        cursor.execute("""
            SELECT 
                s.id,
                c.nome,
                c.cognome,
                l.titolo,
                s.quantita,
                s.data_vendita
            FROM sales s
            JOIN contatti c ON s.contatto_id = c.id
            JOIN libri l ON s.libro_id = l.id
            ORDER BY s.data_vendita DESC
        """)

        vendite = cursor.fetchall()

        return render_template('storico_vendite.html', vendite=vendite)

    except Exception as e:
        return f"Errore nel recupero storico delle vendite: {e}"

#--------------------------------------------------------------------------------------------------------------------------

@app.route('/statistiche')
def statistiche():

    try:

        # Libro più venduto
        cursor.execute("""
            SELECT 
                l.titolo,
                SUM(s.quantita) AS totale_vendite
            FROM sales s
            JOIN libri l ON s.libro_id = l.id
            GROUP BY l.id
            ORDER BY totale_vendite DESC
            LIMIT 1
        """)

        libro_top = cursor.fetchone()


        # Cliente che ha acquistato più libri
        cursor.execute("""
            SELECT 
                c.nome,
                c.cognome,
                SUM(s.quantita) AS totale_acquisti
            FROM sales s
            JOIN contatti c ON s.contatto_id = c.id
            GROUP BY c.id
            ORDER BY totale_acquisti DESC
            LIMIT 1
        """)

        cliente_top = cursor.fetchone()


        # Totale libri venduti
        cursor.execute("SELECT SUM(quantita) FROM sales")

        totale_vendite = cursor.fetchone()


        return render_template(
            'statistiche.html',
            libro_top=libro_top,
            cliente_top=cliente_top,
            totale_vendite=totale_vendite
        )

    except Exception as e:
        return f"Errore nel calcolo delle statistiche: {e}"

#-----------------------------------------------------------------------------------------------------------------------------

#Avvia l'applicazione Flask in modalità debug
if __name__ == '__main__':
    app.run(debug=True)

