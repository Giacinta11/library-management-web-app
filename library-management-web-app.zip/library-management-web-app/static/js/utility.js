class Utility {
    constructor() {
    }

    controllaRangeStringa(stringa, min = null, max = null) {
        let rit = 0;
        const n = stringa.length;
        if (min != null && n < min) {
            rit++;
        }
        if (max != null && n > max) {
            rit++;
        }
        return (rit == 0);
    }

    validaEmail(email) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(email)) {
            return true;
        } else {
            return false;
        }
    }

    soloLettere(str) {
        return /^[A-Za-zÀ-ÖØ-öø-ÿ\s']+$/.test(str);
    }

    validaTelefono(str) {
        return /^\+?[0-9\s]+$/.test(str);
    }

    soloNumeri(valore) {
        const regex = /^[0-9]+$/;
        return regex.test(valore);
    }
}